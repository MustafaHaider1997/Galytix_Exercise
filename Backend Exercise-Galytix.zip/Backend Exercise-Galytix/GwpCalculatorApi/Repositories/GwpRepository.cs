﻿using GwpCalculatorApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GwpCalculatorApi.Repositories
{
    public class GwpRepository : IGwpRepository
    {
        private readonly Dictionary<string, decimal> _gwpData;
        public GwpRepository()
        {
            _gwpData = new Dictionary<string, decimal>
            {
                { "transport", 446001906.1m },
                { "liability", 634545022.9m }
            };
        }
        public Dictionary<string, decimal> GetGwpData()
        {
            //We can setup dapper DB instances to get thee actual data
            return _gwpData;
        }
    }
}
