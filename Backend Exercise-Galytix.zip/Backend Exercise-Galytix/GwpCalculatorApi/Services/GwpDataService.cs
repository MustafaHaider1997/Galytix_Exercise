﻿using GwpCalculatorApi.Controllers;
using GwpCalculatorApi.Interfaces;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GwpCalculatorApi.Services
{
    public class GwpDataService : IGwpDataService
    {
        private readonly IGwpRepository _gwpRepository;
        private readonly ILogger<CountryGwpController> _logger;

        public GwpDataService(IGwpRepository gwpRepository, ILogger<CountryGwpController> logger)
        {
            _gwpRepository = gwpRepository;
            _logger = logger;
        }
        
        public Dictionary<string, decimal> GetGwpData()
        {
            try
            {
                return _gwpRepository.GetGwpData();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while retrieving GWP data");

                return new Dictionary<string, decimal>();
            }
        }
    }
}
