﻿using System;
using System.Collections.Generic;
using GwpCalculatorApi.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace GwpCalculatorApi.Controllers
{
    [Route("server/api/gwp")]
    [ApiController]
    public class CountryGwpController : ControllerBase
    {
        private readonly IGwpDataService _gwpDataService;
        private readonly ILogger<CountryGwpController> _logger;

        public CountryGwpController(IGwpDataService gwpDataService, ILogger<CountryGwpController> logger)
        {
            _gwpDataService = gwpDataService;
            _logger = logger;
        }
        [HttpPost("avg")]
        public async Task<IActionResult> GetAverageGwpAsync([FromBody] GwpRequest request)
        {
            if (request == null)
            {
                return BadRequest("Invalid request body");
            }

            string country = request.Country;
            List<string> lobList = request.Lob;
            if (country == null || lobList == null)
            {
                return BadRequest("Invalid input data");
            }

            try
            {
                var averageGwp = await CalculateAverageGwpAsync(request.Country, request.Lob);
                return Ok(averageGwp);
            }
            catch (Exception ex)
            { 
                _logger.LogError(ex, "An error occurred while processing the request");

                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred");
            }
        }

        public async Task<Dictionary<string, decimal>> CalculateAverageGwpAsync(string country, List<string> lob)
        {
            // Simulate asynchronous data retrieval
            await Task.Delay(TimeSpan.FromSeconds(1));

            // Calling the data service
            var averageGwpData = _gwpDataService.GetGwpData();           

            return averageGwpData;
        }
    }

    public class GwpRequest
    {
        public string Country { get; set; }
        public List<string> Lob { get; set; }
    }
}
