﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GwpCalculatorApi.Interfaces
{
    public interface IGwpDataService
    {
        Dictionary<string, decimal> GetGwpData();
    }
}
