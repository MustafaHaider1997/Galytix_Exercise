using System.Threading.Tasks;
using NUnit.Framework;
using Moq; 
using GwpCalculatorApi.Controllers;
using GwpCalculatorApi.Services;
using GwpCalculatorApi.Interfaces;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;

namespace GwpCalculatorApi.Tests
{
    public class Tests
    {
        [TestFixture]
        public class CountryGwpControllerTests
        {
            [Test]
            public async Task CalculateAverageGwpAsync_WithValidData_ReturnsExpectedResult()
            {
                // Arrange
                var gwpDataMock = new Dictionary<string, decimal>
                {
                    { "transport", 446001906.1m },
                    { "liability", 634545022.9m }
                };

                var gwpDataServiceMock = new Mock<IGwpDataService>();
                var gwpLoggerServiceMock = new Mock<ILogger<CountryGwpController>>();
                gwpDataServiceMock.Setup(mock => mock.GetGwpData()).Returns(gwpDataMock);

                var controller = new CountryGwpController(gwpDataServiceMock.Object, gwpLoggerServiceMock.Object);

                // Act
                var request = new GwpRequest
                {
                    Country = "ae",
                    Lob = new List<string> { "property", "transport" }
                };

                var result = await controller.CalculateAverageGwpAsync(request.Country, request.Lob);

                // Assert
                Assert.IsNotNull(result);

            }
        }
    }
}